create table user(name varchar(255), password varchar(255), phoneNumber varchar(255), email varchar(255));
 
create table user(id int, name varchar(255), password varchar(255), age int, gender enum('male','female','other'),phoneNumber varchar(255), email varchar(255), startDate date, feeStatus enum('pending','paid'),balance int);

<%=name%>